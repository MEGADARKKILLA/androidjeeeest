package com.example.medprac;

import java.text.NumberFormat;

public class analiz {
    public final String name;
    public final String description;
    public final String price;
    public final String timeresult;

    public analiz(String name, String description, String price, String timeresult) {
        NumberFormat numberFormat = NumberFormat.getInstance();
        this.name = name;
        this.description = description;
        this.price = numberFormat.format(price)+"₽";
        this.timeresult = timeresult;
    }
}
