package com.example.medprac;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class vhod_or_reg extends AppCompatActivity {
    public EditText txtmail;
    public Button btnnext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vxod_or_reg);
        txtmail = (EditText) findViewById(R.id.mailbox);
        btnnext = (Button) findViewById(R.id.btnNext);
        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(txtmail.getText().length()>0){
                   Intent intent = new Intent(vhod_or_reg.this, Confirm_email.class);
                   startActivity(intent);
                   finish();
               }
            }
        });
        txtmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(txtmail.getText().length()>0){
                    btnnext.setBackground(getResources().getDrawable(R.drawable.bgbuttonnext));
                    btnnext.setEnabled(true);
                }
                if(txtmail.getText().length()==0){
                    btnnext.setEnabled(false);
                    btnnext.setBackground(getResources().getDrawable(R.drawable.disabled_button));
                }
            }
        });
    }

}
