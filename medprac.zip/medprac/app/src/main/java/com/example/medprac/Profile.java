package com.example.medprac;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Profile extends AppCompatActivity {

        Button mainbtn;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);
        Spinner pol=findViewById(R.id.spin);
        String[] genders= new String[]{getString(R.string.hint_gender),getString(R.string.women),getString(R.string.man)};
        final List<String> genderlist= new ArrayList<>(Arrays.asList(genders));
        final ArrayAdapter<String> spinneradapter = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,genderlist);
        pol.setAdapter(spinneradapter);
        mainbtn = findViewById(R.id.btnmainpage);
        mainbtn.setOnClickListener(v -> {
            Intent intent= new Intent(Profile.this, Main_page.class);
            startActivity(intent);
            finish();
        });
    }
}
