package com.example.medprac;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class onboard1 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.onboard1);
        /*Thread t= new Thread(new Runnable() {
            @Override
            public void run() {
                SharedPreferences getPrefs= PreferenceManager.getDefaultSharedPreferences(getBaseContext());

                boolean isFirstStart = getPrefs.getBoolean("FIRST_START",true);
                if(isFirstStart){
                    Intent i = new Intent(onboard1.this,CustomOnBoard.class);
                    startActivity(i);
                    SharedPreferences.Editor e = getPrefs.edit();
                    e.putBoolean("FIRST_START", false);
                    e.apply();
                }
            }
        });
        t.start();*/
    }
}
