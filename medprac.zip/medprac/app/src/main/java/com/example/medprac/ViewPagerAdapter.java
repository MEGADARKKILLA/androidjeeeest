package com.example.medprac;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
public class ViewPagerAdapter extends PagerAdapter {
    Context context;
    int sliderAllimages1[]={R.drawable._illustrationcolba,R.drawable.cubervrach,R.drawable.vrach};
    int sliderImages2[]={R.drawable.shapekrest,R.drawable.shapekrest,R.drawable.shapekrest};
    int sliderIndicators[]={R.drawable._group2counter1,R.drawable._group2counter2,R.drawable._group2counter3};
    int allTitle[]={R.string.analizi,R.string.yveds,R.string.monitoring};
    int sliderAllDesc[]={R.string.onboardtext1,R.string.onboardtext2,R.string.onboardtext3};
    public  ViewPagerAdapter(Context context){
        this.context=context;
    }
    @Override
    public int getCount() {
        return allTitle.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==(LinearLayout) object;
    }
    @NonNull
    @Override
    public  Object instantiateItem(@NonNull ViewGroup container,int position){
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view= layoutInflater.inflate(R.layout.onboard1,container,false);
        ImageView  sliderImage1= (ImageView) view.findViewById(R.id.sliderImage1);
        ImageView  sliderImage2= (ImageView) view.findViewById(R.id.sliderImage2);
        TextView  sliderTitle= (TextView) view.findViewById(R.id.sliderTitle1);
        TextView  sliderDesc= (TextView) view.findViewById(R.id.sliderDesc1);
        ImageView  sliderIndicator= (ImageView) view.findViewById(R.id.sliderIndicator1);

        sliderImage1.setImageResource(sliderAllimages1[position]);
        sliderImage2.setImageResource(sliderImages2[position]);
        sliderIndicator.setImageResource(sliderIndicators[position]);
        sliderTitle.setText(this.allTitle[position]);
        sliderDesc.setText(this.sliderAllDesc[position]);

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((LinearLayout)object);
    }
}
