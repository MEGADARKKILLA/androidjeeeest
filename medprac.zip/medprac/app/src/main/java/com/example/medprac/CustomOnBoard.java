package com.example.medprac;

import android.content.Intent;
import android.os.Bundle;

import com.github.appintro.AppIntro;
public class CustomOnBoard extends AppIntro {
    public void  init(Bundle savedInstanceState){
        addSlide(sample_onboard.newInstance(R.layout.onboard1));
        addSlide(sample_onboard.newInstance(R.layout.onboard2));
        addSlide(sample_onboard.newInstance(R.layout.onboard3));
    }
    private  void loadMainActivity(){
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }
    public  void OnNextPressed(){
    }
    public  void OnDonePressed(){
        finish();
    }
    public  void OnSlidePressed(){
    }
}
