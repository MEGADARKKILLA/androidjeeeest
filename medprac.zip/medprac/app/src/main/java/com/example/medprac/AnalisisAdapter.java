package com.example.medprac;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AnalisisAdapter extends RecyclerView.Adapter<AnalisisAdapter.ViewHolder> {
    private final LayoutInflater inflater;
    private final List<AnalisisData> list;

    public AnalisisAdapter(Context context, List<AnalisisData> list) {
        this.inflater = LayoutInflater.from(context);
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.main_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AnalisisData data = list.get(position);
        Log.e("!!!", data.name.toString());
        holder.name_main.setText(data.name);
        holder.price_main.setText(data.price);
        holder.time_results.setText(data.timeresult);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        final TextView name_main, price_main, time_results;

        public ViewHolder(View itemView) {
            super(itemView);
            name_main = itemView.findViewById(R.id.name_main);
            price_main = itemView.findViewById(R.id.price_main);
            time_results = itemView.findViewById(R.id.time_results_main);
        }
    }


}
