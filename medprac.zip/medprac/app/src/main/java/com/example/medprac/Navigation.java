package com.example.medprac;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class Navigation extends AppCompatActivity {
    ViewPager slideViewPager;
    ViewPagerAdapter viewPagerAdapter;
    TextView nextTextview;

    ViewPager.OnPageChangeListener viewPagerListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            if(position==2){
                nextTextview.setText(R.string.end);
            }
            if(position<2){
                nextTextview.setText(R.string.skip);
            }
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_lay);

        nextTextview=findViewById(R.id.skip_txt);
        nextTextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                   Intent intent = new Intent(Navigation.this, vhod_or_reg.class);
                   startActivity(intent);
                finish();
            }
        });
        slideViewPager = (ViewPager) findViewById(R.id.slideViewPager);
        viewPagerAdapter = new ViewPagerAdapter(this);
        slideViewPager.setAdapter(viewPagerAdapter);
        slideViewPager.addOnPageChangeListener(viewPagerListener);
    }
    private int getItem(int i){
        return slideViewPager.getCurrentItem()+i;
    }
}
