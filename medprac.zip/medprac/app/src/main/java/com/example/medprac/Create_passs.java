package com.example.medprac;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Create_passs extends AppCompatActivity {
    TextView skip;
    int[] code = new int[4];
    ImageView doot1;
    ImageView doot2;
    ImageView doot3;
    ImageView doot4;
    ImageView[] imgmass = new ImageView[3];
    int position=0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_pass);
        doot1= findViewById(R.id.dot1);
        doot2= findViewById(R.id.dot2);
        doot3= findViewById(R.id.dot3);
        doot4= findViewById(R.id.dot4);
        imgmass = new ImageView[]{doot1,doot2,doot3,doot4};
        skip=findViewById(R.id.skiptxt);
        skip.setOnClickListener(v -> {
            Intent intent= new Intent(Create_passs.this, Create_Pacient.class);
            startActivity(intent);
            finish();
        });
    }
    public void onClick(View view){
        int id= view.getId();
        if(position<=3 && position>=0) {
            if (id == R.id.btn1) {
                code[position] = 1;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            } else if (id == R.id.btn2) {
                code[position] = 2;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            } else if (id == R.id.btn3) {
                code[position] = 3;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            } else if (id == R.id.btn4) {
                code[position] = 4;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            } else if (id == R.id.btn5) {
                code[position] = 5;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            } else if (id == R.id.btn6) {
                code[position] = 6;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            } else if (id == R.id.btn7) {
                code[position] = 7;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            } else if (id == R.id.btn8) {
                code[position] = 8;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            } else if (id == R.id.btn9) {
                code[position] = 9;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            } else if (id == R.id.btn0) {
                code[position] = 0;
                imgmass[position].setImageResource(R.drawable.colored_dot);
                position++;
            }
        }
            if (id == R.id.btnnazad && position>0) {
                //clear
                code[position - 1] = 0;
                imgmass[position - 1].setImageResource(R.drawable.empty_pass);
                position--;
            }
        if(position==4){
            Intent intent= new Intent(Create_passs.this, Create_Pacient.class);
            startActivity(intent);
            finish();
        }
    }
}
