package com.example.medprac;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Confirm_email extends AppCompatActivity
{
    EditText mailtxt1;
    EditText mailtxt2;
    EditText mailtxt3;
    EditText mailtxt4;
    TextView countd;
    Button btnback;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.confirm_email);

        mailtxt1=findViewById(R.id.mailtext1);
        mailtxt2=findViewById(R.id.mailtext2);
        mailtxt3=findViewById(R.id.mailtext3);
        mailtxt4=findViewById(R.id.mailtext4);
        countd = findViewById(R.id.countdown);
        btnback = findViewById(R.id.btnbackmail);
        btnback.setOnClickListener(v -> {
            Intent intent = new Intent(Confirm_email.this, vhod_or_reg.class);
            startActivity(intent);
            finish();
        });
        mailtxt1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(mailtxt1.getText().length()==1){
                    mailtxt2.requestFocus();
                }
            }
        });
        mailtxt2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(mailtxt2.getText().length()==1){
                    mailtxt3.requestFocus();
                }
                else if(mailtxt2.getText().length()==0){
                    mailtxt1.requestFocus();
                }
            }
        });
        mailtxt3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(mailtxt3.getText().length()==1){
                    mailtxt4.requestFocus();
                }
                else if(mailtxt3.getText().length()==0){
                    mailtxt2.requestFocus();
                }
            }
        });

        mailtxt4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //проверка на правильность кода
                Intent intent = new Intent(Confirm_email.this, Create_passs.class);
                startActivity(intent);
                finish();
            }
            @Override
            public void afterTextChanged(Editable s) {

                if(mailtxt4.getText().length()==0){
                    mailtxt3.requestFocus();
                }
            }
        });
        CountDownTimer countDownTimer = new CountDownTimer(60000, 1000) {
            int i=60;
            @Override
            public void onTick(long millisUntilFinished) {

                String seconds;
                if((i<=60&&i>=55)||(i<=50&&i>=45)||(i<=40&&i>=35)||(i<=30&&i>=25)||(i<=20&&i>=15)||(i<=10&&i>=5))
                {
                seconds = getString(R.string.seconds1);
                }
                else if ((i<=54&&i>=52)||(i<=44&&i>=42)||(i<=34&&i>=32)||(i<=24&&i>=22)||(i<=14&&i>=12)||(i<=4&&i>=2)) {
                    seconds = getString(R.string.seconds3);
                }
                else {
                    seconds = getString(R.string.seconds2);
                }
                countd.setText(getString(R.string.code_pt1)+" "+i+" "+seconds);
                i--;
            }

            @Override
            public void onFinish() {
                countd.setText(getString(R.string.codeagain));
                countd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //какое то действие
                    }
                });
            }
        }.start();


    }
}
