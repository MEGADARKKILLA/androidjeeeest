package com.example.medprac;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Create_Pacient extends AppCompatActivity {
    TextView skip;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_pacient);
        skip=findViewById(R.id.txtskip);
        skip.setOnClickListener(v -> {
            Intent intent= new Intent(Create_Pacient.this, Main_page.class);
            startActivity(intent);
            finish();
        });
        Spinner pol=findViewById(R.id.spin);
        String[] genders= new String[]{getString(R.string.hint_gender),getString(R.string.women),getString(R.string.man)};
        final List<String> genderlist= new ArrayList<>(Arrays.asList(genders));
        final ArrayAdapter<String> spinneradapter = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,genderlist);
        pol.setAdapter(spinneradapter);
    }
}
