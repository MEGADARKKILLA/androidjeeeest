package com.example.medprac;

public class News {
    public final String name;
    public final String price;

    public News(String name, String price) {
        this.name = name;
        this.price = price+"₽";
    }
}
