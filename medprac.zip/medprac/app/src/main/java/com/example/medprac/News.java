package com.example.medprac;

public class News {
    public final String name;
    public final String description;
    public final String price;

    public News(String name, String description, String price) {
        this.name = name;
        this.description = description;
        this.price = price+"₽";
    }
}
