package com.example.medprac;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Main_page extends AppCompatActivity {
    Button profileb;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page);
        profileb=findViewById(R.id.profile_btn);
        profileb.setOnClickListener(v -> {
            Intent intent = new Intent(Main_page.this, Profile.class);
            startActivity(intent);
            finish();
        });

    }
}
