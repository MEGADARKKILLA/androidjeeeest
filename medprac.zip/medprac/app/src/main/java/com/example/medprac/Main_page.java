package com.example.medprac;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Main_page extends AppCompatActivity {
    Button profileb;
    private List<analiz> analizList = new ArrayList<>();
    private Analiz_main_adapter analizMainAdapter;
    private ListView listViewMain;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page);
        profileb=findViewById(R.id.profile_btn);
        profileb.setOnClickListener(v -> {
            Intent intent = new Intent(Main_page.this, Profile.class);
            startActivity(intent);
            finish();
        });
        listViewMain = (ListView) findViewById(R.id.main_an);
        analizMainAdapter =new Analiz_main_adapter(this,analizList);
        listViewMain.setAdapter(analizMainAdapter);
        URL url = createUrl();
        if(url!=null){
            GetAnalizTask getAnalizTask = new GetAnalizTask();
            getAnalizTask.execute(url);
        }
        else{
            Snackbar.make(findViewById(R.id.frame),"Invalid url",Snackbar.LENGTH_LONG).show();
        }
    }
    private URL createUrl() {
        try{
            String urlString ="http://10.0.2.2:8000/api/catalog/";
            return  new URL(urlString);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return  null;
    }
   private class GetAnalizTask extends AsyncTask<URL,Void, JSONObject>{
        @Override
       protected JSONObject doInBackground(URL...params){
            HttpURLConnection connection = null;
            try{
                connection = (HttpURLConnection) params[0].openConnection();
                int responce=connection.getResponseCode();
                if(responce==HttpURLConnection.HTTP_OK){
                    StringBuilder builder = new StringBuilder();
                    try(BufferedReader reader= new BufferedReader( new InputStreamReader(connection.getInputStream()))) {
                        String line;
                        while ((line=reader.readLine())!=null){
                            builder.append(line);
                        }
                    }
                    catch (Exception e){
                        Snackbar.make(findViewById(R.id.frame),"Unable to read data",Snackbar.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                    return  new JSONObject(builder.toString());
                }
                else {
                    Snackbar.make(findViewById(R.id.frame),"unable to connect",Snackbar.LENGTH_LONG).show();
                }
            }
            catch (Exception e){
                Snackbar.make(findViewById(R.id.frame),"unable to connect",Snackbar.LENGTH_LONG).show();
                e.printStackTrace();
                Log.e("!",e.getMessage());
            }
            finally {
                connection.disconnect();
            }
            return null;
        }
        @Override
       protected  void onPostExecute(JSONObject analizi){
            convertJSONtoArrayList(analizi);
            analizMainAdapter.notifyDataSetChanged();
            listViewMain.smoothScrollToPosition(0);
        }

       private void convertJSONtoArrayList(JSONObject analizi) {
            analizList.clear();
            try {
                JSONArray list =analizi.getJSONArray("results");

                for(int i=0; i<list.length();++i){
                    JSONObject an1=list.getJSONObject(i);

                    JSONObject about=an1.getJSONObject("results");
                    analizList.add(new analiz(
                            an1.getString("name"),
                            an1.getString("time_result"),
                            an1.getString("price"),
                            an1.getString("Description")
                    ));
                }
            }
            catch (JSONException e){
                e.printStackTrace();
            }
       }
   }
}
