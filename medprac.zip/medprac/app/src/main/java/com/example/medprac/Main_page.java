package com.example.medprac;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Main_page extends AppCompatActivity {
    Button profileb;
    private List<AnalisisData> analizList = new ArrayList<>();
    private AnalisisAdapter analisisAdapter;
    private RecyclerView recyclerView;
    //news
    private RecyclerView newsview;
    private List<News> newsList = new ArrayList<>();
    private NewsAdapter newsAdapter;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page);
        profileb=findViewById(R.id.profile_btn);
        profileb.setOnClickListener(v -> {
            Intent intent = new Intent(Main_page.this, Profile.class);
            startActivity(intent);
            finish();
        });
        recyclerView = (RecyclerView) findViewById(R.id.main_an);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        analisisAdapter = new AnalisisAdapter(this, analizList);
        recyclerView.setAdapter(analisisAdapter);
        //news
        newsview =(RecyclerView)findViewById(R.id.newslist);
        newsview.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        newsAdapter = new NewsAdapter(this,newsList);
        newsview.setAdapter(newsAdapter);

        URL url = createUrl();
        //news
        URL url2= createUrl2();
        if(url!=null){
            GetAnalizTask getAnalizTask = new GetAnalizTask();
            getAnalizTask.execute(url);
            //news
        }
        else{
            Snackbar.make(findViewById(R.id.frame),"Invalid url",Snackbar.LENGTH_LONG).show();
        }
        if(url2!=null){
            GetNewsTask getNewsTask= new GetNewsTask();
            getNewsTask.execute(url2);
        }
        else{
            Snackbar.make(findViewById(R.id.frame),"Invalid url",Snackbar.LENGTH_LONG).show();
        }
    }
    private URL createUrl() {
        try{
            String urlString ="http://10.0.2.2:8000/api/catalog/";
            return  new URL(urlString);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return  null;
    }
    //news
    private URL createUrl2() {
        try{
            String urlString ="http://10.0.2.2:8000/api/news/";
            return  new URL(urlString);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return  null;
    }
   private class GetAnalizTask extends AsyncTask<URL,Void, JSONObject>{
        @Override
       protected JSONObject doInBackground(URL...params){
            HttpURLConnection connection = null;
            try{
                connection = (HttpURLConnection) params[0].openConnection();
                int responce=connection.getResponseCode();
                if(responce==HttpURLConnection.HTTP_OK){
                    StringBuilder builder = new StringBuilder();
                    try(BufferedReader reader= new BufferedReader( new InputStreamReader(connection.getInputStream()))) {
                        String line;
                        while ((line=reader.readLine())!=null){
                            builder.append(line);
                        }
                    }
                    catch (Exception e){
                        Snackbar.make(findViewById(R.id.frame),"Unable to read data",Snackbar.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                    return  new JSONObject(builder.toString());
                }
                else {
                    Snackbar.make(findViewById(R.id.frame),"unable to connect",Snackbar.LENGTH_LONG).show();
                }
            }
            catch (Exception e){
                Snackbar.make(findViewById(R.id.frame),"unable to connect",Snackbar.LENGTH_LONG).show();
                e.printStackTrace();
                Log.e("!",e.getMessage());
            }
            finally {
                connection.disconnect();
            }
            return null;
        }

       @Override
       protected void onPostExecute(JSONObject jsonObject) {
           Log.e("!!!onPostExecute", jsonObject.toString());
           convertJSONtoArrayList(jsonObject);
           analisisAdapter.notifyDataSetChanged();
           recyclerView.smoothScrollToPosition(0);
       }
   }
   //news
    private class GetNewsTask extends AsyncTask<URL,Void, JSONObject>{
        @Override
        protected JSONObject doInBackground(URL...params){
            HttpURLConnection connection = null;
            try{
                connection = (HttpURLConnection) params[0].openConnection();
                int responce=connection.getResponseCode();
                if(responce==HttpURLConnection.HTTP_OK){
                    StringBuilder builder = new StringBuilder();
                    try(BufferedReader reader= new BufferedReader( new InputStreamReader(connection.getInputStream()))) {
                        String line;
                        while ((line=reader.readLine())!=null){
                            builder.append(line);
                        }
                    }
                    catch (Exception e){
                        Snackbar.make(findViewById(R.id.frame),"Unable to read data",Snackbar.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                    return  new JSONObject(builder.toString());
                }
                else {
                    Snackbar.make(findViewById(R.id.frame),"unable to connect",Snackbar.LENGTH_LONG).show();
                }
            }
            catch (Exception e){
                Snackbar.make(findViewById(R.id.frame),"unable to connect",Snackbar.LENGTH_LONG).show();
                e.printStackTrace();
                Log.e("!",e.getMessage());
            }
            finally {
                connection.disconnect();
            }
            return null;
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject) {
            Log.e("!!!onPostExecute2", jsonObject.toString());
            convertJSONtoArrayListNews(jsonObject);
            newsAdapter.notifyDataSetChanged();
            newsview.smoothScrollToPosition(0);
        }
    }

    private void convertJSONtoArrayList(JSONObject analizi) {
        analizList.clear();
        try {
            JSONArray list =analizi.getJSONArray("results");
            Log.e("!!!convertJSONtoArrayList", list.toString());

            for(int i=0; i<list.length();++i){
                JSONObject an1=list.getJSONObject(i);
                Log.e("!!!results_name", an1.getString("name"));
                Log.e("!!!an1", an1.toString());
                Log.e("!!!i", ""+i);
                analizList.add(new AnalisisData(
                        an1.getString("name"),
                        an1.getString("description"),
                        an1.getString("price"),
                        an1.getString("time_result")
                ));
                Log.e("!!!analizList", analizList.toString());
            }
        }
        catch (Exception e){
            Log.wtf("!!!!!", e.getLocalizedMessage());
            e.printStackTrace();
        }
    }
    //news
    private void convertJSONtoArrayListNews(JSONObject news) {
        newsList.clear();
        try {
            JSONArray list =news.getJSONArray("results");
            Log.e("!!!convertJSONtoArrayListNews", list.toString());

            for(int i=0; i<list.length();++i){
                JSONObject an1=list.getJSONObject(i);
                Log.e("!!!results_name", an1.getString("name"));
                Log.e("!!!an1", an1.toString());
                Log.e("!!!i", ""+i);
                newsList.add(new News(
                        an1.getString("name"),
                        an1.getString("price")
                ));
                Log.e("!!!newsList", newsList.toString());
            }
        }
        catch (Exception e){
            Log.wtf("!!!!!", e.getLocalizedMessage());
            e.printStackTrace();
        }
    }
}
