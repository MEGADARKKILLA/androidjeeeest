package com.example.medprac;

public class AnalisisData {
    public final String name;
    public final String description;
    public final String price;
    public final String timeresult;

    public AnalisisData(String name, String description, String price, String timeresult) {
        this.name = name;
        this.description = description;
        this.price = price+"₽";
        this.timeresult = timeresult;
    }
}
