package com.example.medprac;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class sample_onboard extends Fragment {
    private  static final  String Layout_id="Layout_id";
    public  static  sample_onboard newInstance(int layout_id){
        sample_onboard sampleOnboard = new sample_onboard();
        Bundle args = new Bundle();
        args.putInt(Layout_id,layout_id);
        sampleOnboard.setArguments(args);
        return sampleOnboard;
    }
    private int layout_id;
    public sample_onboard(){}
    @Override
    public  void  onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        if(getArguments() != null && getArguments().containsKey(Layout_id))
            layout_id=getArguments().getInt(Layout_id);
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,@Nullable Bundle savedInstanceState){
        return inflater.inflate(layout_id,container,false);
    }
}
