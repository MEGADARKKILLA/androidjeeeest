package com.example.medprac;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class Analiz_main_adapter extends ArrayAdapter<analiz> {
    private static class ViewHolder{
        TextView priceText;
        TextView nameText;
        TextView timeResText;
    }
    public Analiz_main_adapter(Context context, List<analiz> analiz1){
        super(context,-1);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        analiz an1= getItem(position);
        ViewHolder viewHolder;
        if(convertView==null){
            viewHolder = new ViewHolder();
            LayoutInflater inflater =LayoutInflater.from(getContext());
            convertView =inflater.inflate(R.layout.main_list,parent,false);
            viewHolder.priceText =(TextView)convertView.findViewById(R.id.price_main);
            viewHolder.nameText =(TextView)convertView.findViewById(R.id.name_main);
            viewHolder.timeResText=(TextView)convertView.findViewById(R.id.time_results_main);
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder=(ViewHolder)convertView.getTag();
        }

        Context context=getContext();
        viewHolder.priceText.setText(an1.price);
        viewHolder.nameText.setText(an1.name);
        viewHolder.timeResText.setText(an1.timeresult);
        return convertView;
    }
}
